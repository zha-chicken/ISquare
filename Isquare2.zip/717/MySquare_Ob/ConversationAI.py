import ollama #line:1
from datetime import datetime #line:2
import AnalyzeAI #line:3
from flask import Flask ,request ,jsonify #line:4
import threading #line:5
import time #line:6
import os #line:7
import re #line:8
app =Flask (__name__ )#line:11
DIALOG_LOG ="conversation_log.txt"#line:14
QUESTION_LOG ="user_questions.log"#line:15
usrcharacteristics ="暂无数据"#line:18
last_update_time =0 #line:19
def extract_user_info (OOO0OOOOOOOO00O0O ):#line:21
    OO0O0OOOO00OO00O0 =r'情绪[：:\s]*(.*?)(?=[\n,，]|$)'#line:23
    OO00OO0O0O000O0O0 =r'喜好[：:\s]*(.*?)(?=[\n,，]|$)'#line:24
    O0OOOO000OOO000OO =r'目标[：:\s]*(.*?)(?=[\n,，]|$)'#line:25
    O00OOOO0OOOOOO00O =re .findall (OO0O0OOOO00OO00O0 ,OOO0OOOOOOOO00O0O ,re .DOTALL )#line:28
    OOO00000000OO0O0O =re .findall (OO00OO0O0O000O0O0 ,OOO0OOOOOOOO00O0O ,re .DOTALL )#line:29
    OOOO0OOOO0O0OOO00 =re .findall (O0OOOO000OOO000OO ,OOO0OOOOOOOO00O0O ,re .DOTALL )#line:30
    def O0OOO00O0O000O00O (OOOOO0O000OOOO00O ):#line:33
        if not OOOOO0O000OOOO00O :#line:34
            return None #line:35
        OO0OOO00OO00OOOOO =[OO00OO0000O000000 .replace ('**','').replace ('"','').strip ()for OO00OO0000O000000 in OOOOO0O000OOOO00O ]#line:38
        O0OO0O00O00OOO00O =[OOO0OOO0OO000OO00 for OOO0OOO0OO000OO00 in OO0OOO00OO00OOOOO if OOO0OOO0OO000OO00 ]#line:40
        return O0OO0O00O00OOO00O [-1 ]if O0OO0O00O00OOO00O else None #line:41
    O0OOO00OO0O000000 =O0OOO00O0O000O00O (O00OOOO0OOOOOO00O )#line:43
    O0OOOOO00OO0O0000 =O0OOO00O0O000O00O (OOO00000000OO0O0O )#line:44
    OOOO0OO0OO000O0OO =O0OOO00O0O000O00O (OOOO0OOOO0O0OOO00 )#line:45
    OOOOOO0O00O0O0O00 =[]#line:48
    if O0OOO00OO0O000000 :#line:49
        OOOOOO0O00O0O0O00 .append (f"情绪：{O0OOO00OO0O000000}")#line:50
    if O0OOOOO00OO0O0000 :#line:51
        OOOOOO0O00O0O0O00 .append (f"喜好：{O0OOOOO00OO0O0000}")#line:52
    if OOOO0OO0OO000O0OO :#line:53
        OOOOOO0O00O0O0O00 .append (f"目标：{OOOO0OO0OO000O0OO}")#line:54
    return "\n".join (OOOOOO0O00O0O0O00 )#line:56
def update_user_characteristics ():#line:58
    ""#line:59
    global usrcharacteristics ,last_update_time #line:60
    while True :#line:61
        try :#line:62
            with open ('user_characteristics.txt','r',encoding ='ANSI')as O0OO00000O0O00OOO :#line:63
                OOO0OO00OOOO00000 =O0OO00000O0O00OOO .read ()#line:64
                OO0000OO0OO00OO00 =extract_user_info (OOO0OO00OOOO00000 )#line:65
                if OO0000OO0OO00OO00 !=usrcharacteristics :#line:66
                    usrcharacteristics =OO0000OO0OO00OO00 #line:67
                    print (f"用户特征已更新: {usrcharacteristics[:50]}...")#line:68
                    last_update_time =time .time ()#line:69
        except Exception as OO00O0O0O0000OO00 :#line:70
            print (f"读取用户特征文件出错(可以忽略): {OO00O0O0O0000OO00}")#line:71
            usrcharacteristics =''#line:72
        time .sleep (10 )#line:73
def log_question (OOOO000O0OO0O000O ):#line:75
    ""#line:76
    OOOO0O000OO00O00O =datetime .now ().strftime ("%Y-%m-%d %H:%M:%S")#line:77
    with open (QUESTION_LOG ,"a",encoding ="utf-8")as OO0000OO0OO00O0OO :#line:78
        OO0000OO0OO00O0OO .write (f"[{OOOO0O000OO00O00O}] {OOOO000O0OO0O000O}\n")#line:79
def log_dialog (O0O000OOO0O0O0OO0 ,OO00O0000O0OO000O ):#line:81
    ""#line:82
    OO000OO00O00O0000 =datetime .now ().strftime ("%Y-%m-%d %H:%M:%S")#line:83
    with open (DIALOG_LOG ,"a",encoding ="utf-8")as O00O00OO00O0O00O0 :#line:84
        O00O00OO00O0O00O0 .write (f"[{OO000OO00O00O0000}] 用户: {O0O000OOO0O0O0OO0}\n")#line:85
        O00O00OO00O0O00O0 .write (f"[{OO000OO00O00O0000}] AI: {OO00O0000O0OO000O}\n")#line:86
        O00O00OO00O0O00O0 .write ("-"*50 +"\n")#line:87
def initialize_logs ():#line:89
    ""#line:90
    with open (QUESTION_LOG ,"a",encoding ="utf-8")as O00O0O0OO00O000OO :#line:91
        O00O0O0OO00O000OO .write ("\n"+"="*30 +f" 新会话开始 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} "+"="*30 +"\n")#line:92
    with open (DIALOG_LOG ,"a",encoding ="utf-8")as O00O0O0OO00O000OO :#line:94
        O00O0O0OO00O000OO .write ("\n"+"="*30 +f" 新对话开始 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} "+"="*30 +"\n")#line:95
def initialize_model ():#line:97
    ""#line:98
    try :#line:99
        ollama .pull ('deepseek-r1:1.5b')#line:100
        print ("模型加载成功")#line:101
        return True #line:102
    except Exception as OO0O000O00O0OO0O0 :#line:103
        print (f"模型加载错误: {OO0O000O00O0OO0O0}")#line:104
        return False #line:105
@app .route ('/api/ask',methods =['POST'])#line:107
def handle_question ():#line:108
    ""#line:109
    O0OOOO0O00OO00OO0 =request .json #line:110
    if not O0OOOO0O00OO00OO0 or 'question'not in O0OOOO0O00OO00OO0 :#line:111
        return jsonify ({'error':'Missing question parameter'}),400 #line:112
    OO0OOO0O0O0OO0O00 =O0OOOO0O00OO00OO0 ['question'].strip ()#line:114
    if not OO0OOO0O0O0OO0O00 :#line:115
        return jsonify ({'error':'Question is empty'}),400 #line:116
    if OO0OOO0O0O0OO0O00 =='清除个性化配置':#line:117
            os .remove ("user_characteristics.txt")#line:118
            os .remove ("user_questions.log")#line:119
            print ("个性化数据已清除, 正在重新启动服务")#line:120
            os .system ("restart_service.py")#line:121
    log_question (OO0OOO0O0O0OO0O00 )#line:124
    try :#line:126
        O0O00000O00O00OO0 =f"我目前的状态是：{usrcharacteristics}请依照这个给我回答{OO0OOO0O0O0OO0O00}"#line:129
        OOO00O00O00O0OOOO =ollama .generate (model ='deepseek-r1:1.5b',prompt =O0O00000O00O00OO0 )#line:135
        O0000O0O0OO00O0OO =OOO00O00O00O0OOOO ['response']#line:136
        log_dialog (OO0OOO0O0O0OO0O00 ,O0000O0O0OO00O0OO )#line:139
        threading .Thread (target =AnalyzeAI .analyze_user_questions ).start ()#line:142
        return jsonify ({'answer':O0000O0O0OO00O0OO ,'characteristics':usrcharacteristics ,'timestamp':datetime .now ().isoformat ()})#line:148
    except Exception as O000O0O000O0OOOO0 :#line:150
        O0O0OO000OOOO00O0 =f"发生错误: {O000O0O000O0OOOO0}"#line:151
        print (O0O0OO000OOOO00O0 )#line:152
        return jsonify ({'error':O0O0OO000OOOO00O0 }),500 #line:153
@app .route ('/api/status',methods =['GET'])#line:155
def get_status ():#line:156
    ""#line:157
    return jsonify ({'status':'running','last_characteristics_update':last_update_time ,'model':'deepseek-r1:1.5b'})#line:162
if __name__ =='__main__':#line:164
    initialize_logs ()#line:166
    if not initialize_model ():#line:169
        print ("无法启动服务，模型加载失败")#line:170
        exit (1 )#line:171
    threading .Thread (target =update_user_characteristics ,daemon =True ).start ()#line:174
    print ("API服务已启动，等待请求...")#line:176
    app .run (host ='0.0.0.0',port =8080 ,debug =False )