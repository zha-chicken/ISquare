import os
import sys
import subprocess
import time
import signal

def restart_service():
    """重启API服务"""
    try:
        # 1. 查找当前运行的API服务进程
        current_pid = None
        for line in os.popen('ps aux | grep "python ConversationAI.py" | grep -v grep'):
            parts = line.split()
            if len(parts) > 1:
                current_pid = int(parts[1])
                break
        
        if current_pid:
            print(f"找到正在运行的服务进程 PID: {current_pid}")
            
            # 2. 优雅终止当前进程
            print("正在停止服务...")
            try:
                os.kill(current_pid, signal.SIGTERM)  # 发送终止信号
                time.sleep(2)  # 等待进程退出
                
                # 检查是否已停止
                if os.path.exists(f"/proc/{current_pid}"):
                    print("进程未正常退出，强制终止...")
                    os.kill(current_pid, signal.SIGKILL)
            except ProcessLookupError:
                print("进程已退出")
        
        # 3. 启动新服务
        print("启动新服务...")
        # 使用nohup在后台运行并重定向输出
        subprocess.Popen(
            ["nohup", "python3", "ConversationAI.py", ">", "api_service.log", "2>&1", "&"],
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        print("服务重启成功!")
        return True
    
    except Exception as e:
        print(f"重启失败: {str(e)}")
        return False

if __name__ == "__main__":
    restart_service()