import ollama
from datetime import datetime
import AnalyzeAI
from flask import Flask, request, jsonify
import threading
import time
import os
import re

# 创建Flask应用
app = Flask(__name__)

# 文件定义
DIALOG_LOG = "conversation_log.txt"  # 完整对话记录
QUESTION_LOG = "user_questions.log"   # 单独的用户提问记录

# 全局变量存储用户特征
usrcharacteristics = "暂无数据"
last_update_time = 0

def extract_user_info(text):
    # 定义正则表达式模式
    emotion_pattern = r'情绪[：:\s]*(.*?)(?=[\n,，]|$)'
    preference_pattern = r'喜好[：:\s]*(.*?)(?=[\n,，]|$)'
    goal_pattern = r'目标[：:\s]*(.*?)(?=[\n,，]|$)'
    
    # 查找所有匹配项
    emotions = re.findall(emotion_pattern, text, re.DOTALL)
    preferences = re.findall(preference_pattern, text, re.DOTALL)
    goals = re.findall(goal_pattern, text, re.DOTALL)
    
    # 清理结果并取最后一个有效值
    def clean_result(result_list):
        if not result_list:
            return None
        # 去除多余符号和空格
        cleaned = [res.replace('**', '').replace('"', '').strip() 
                  for res in result_list]
        # 过滤空值并取最后一个
        non_empty = [res for res in cleaned if res]
        return non_empty[-1] if non_empty else None
    
    emotion = clean_result(emotions)
    preference = clean_result(preferences)
    goal = clean_result(goals)
    
    # 构建结果字符串
    result_parts = []
    if emotion:
        result_parts.append(f"情绪：{emotion}")
    if preference:
        result_parts.append(f"喜好：{preference}")
    if goal:
        result_parts.append(f"目标：{goal}")
    
    return "\n".join(result_parts)

def update_user_characteristics():
    """定期更新用户特征"""
    global usrcharacteristics, last_update_time
    while True:
        try:
            with open('user_characteristics.txt', 'r', encoding='ANSI') as file:
                content = file.read()
                new_characteristics = extract_user_info(content)
                if new_characteristics != usrcharacteristics:
                    usrcharacteristics = new_characteristics
                    print(f"用户特征已更新: {usrcharacteristics[:50]}...")
                    last_update_time = time.time()
        except Exception as e:
            print(f"读取用户特征文件出错(可以忽略): {e}")
            usrcharacteristics = ''
        time.sleep(10)  # 每10秒检查一次更新

def log_question(user_input):
    """单独记录用户提问"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(QUESTION_LOG, "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {user_input}\n")

def log_dialog(user_input, ai_response):
    """记录完整对话"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(DIALOG_LOG, "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] 用户: {user_input}\n")
        f.write(f"[{timestamp}] AI: {ai_response}\n")
        f.write("-" * 50 + "\n")

def initialize_logs():
    """初始化日志文件头"""
    with open(QUESTION_LOG, "a", encoding="utf-8") as f:
        f.write("\n" + "="*30 + f" 新会话开始 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} " + "="*30 + "\n")
    
    with open(DIALOG_LOG, "a", encoding="utf-8") as f:
        f.write("\n" + "="*30 + f" 新对话开始 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} " + "="*30 + "\n")

def initialize_model():
    """初始化模型"""
    try:
        ollama.pull('deepseek-r1:1.5b')
        print("模型加载成功")
        return True
    except Exception as e:
        print(f"模型加载错误: {e}")
        return False

@app.route('/api/ask', methods=['POST'])
def handle_question():
    """处理用户提问的API端点"""
    data = request.json
    if not data or 'question' not in data:
        return jsonify({'error': 'Missing question parameter'}), 400
    
    user_question = data['question'].strip()
    if not user_question:
        return jsonify({'error': 'Question is empty'}), 400
    if user_question == '清除个性化配置':
            os.remove("user_characteristics.txt")
            os.remove("user_questions.log")
            print("个性化数据已清除, 正在重新启动服务")
            os.system("restart_service.py")
    
    # 记录用户问题
    log_question(user_question)
    
    try:
       
        # 构建输入提示
        input_prompt = f"我目前的状态是：{usrcharacteristics}请依照这个给我回答{user_question}"
        
        # 与模型交互
        response = ollama.generate(
            model='deepseek-r1:1.5b',
            prompt=input_prompt
        )
        ai_response = response['response']
        
        # 记录完整对话
        log_dialog(user_question, ai_response)
        
        # 分析用户问题（异步执行避免阻塞API响应）
        threading.Thread(target=AnalyzeAI.analyze_user_questions).start()
        
        return jsonify({
            'answer': ai_response,
            'characteristics': usrcharacteristics,
            'timestamp': datetime.now().isoformat()
        })
    
    except Exception as e:
        error_msg = f"发生错误: {e}"
        print(error_msg)
        return jsonify({'error': error_msg}), 500

@app.route('/api/status', methods=['GET'])
def get_status():
    """获取服务状态"""
    return jsonify({
        'status': 'running',
        'last_characteristics_update': last_update_time,
        'model': 'deepseek-r1:1.5b'
    })

if __name__ == '__main__':
    # 初始化日志
    initialize_logs()
    
    # 初始化模型
    if not initialize_model():
        print("无法启动服务，模型加载失败")
        exit(1)
    
    # 启动用户特征更新线程
    threading.Thread(target=update_user_characteristics, daemon=True).start()
    
    print("API服务已启动，等待请求...")
    app.run(host='0.0.0.0', port=8080, debug=False)