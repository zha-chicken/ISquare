

# 创建打包脚本 (package.py)
import os
import PyInstaller.__main__

# 获取当前目录
current_dir = os.path.dirname(os.path.abspath(__file__))

# 打包配置
PyInstaller.__main__.run([
    'ConversationAI.py',       # 主入口文件
    '--onefile',               # 单文件打包             # 无控制台窗口
    '--name=ISQUARE-API',      # 输出名称
    '--add-data=AnalyzeAI.py;.',  # 包含依赖文件
    '--add-data=restart_service.py;.',
    '--noconsole',  
    '--hidden-import=Crypto',   # 隐藏依赖
    '--hidden-import=flask_cors',
    '--clean'                  # 清理临时文件
])